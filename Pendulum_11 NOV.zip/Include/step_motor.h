/*
 * step_motor.h
 *
 *  Created on: Sep 19, 2025
 *      Author: TulusS'26
 */

#ifndef STEP_MOTOR_H_
#define STEP_MOTOR_H_
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>


void geserKanan(){
	  if (HAL_GPIO_ReadPin(BT2_GPIO_Port, BT2_Pin) == GPIO_PIN_RESET){
			// sprintf(msg, "KIRI -> Encoder_A: %d\r\n Encoder_B: %d\r\n", last_encoder, last_encoder1);
			 //CDC_Transmit_FS((uint8_t*)msg, strlen(msg));

			 if ( HAL_GPIO_ReadPin(Limit2_GPIO_Port, Limit2_Pin) == GPIO_PIN_RESET){
				// sprintf(lmt, "KIRI -> Encoder_A: %d\r\n Encoder_B: %d\r\n", last_encoder, last_encoder1);
				 //CDC_Transmit_FS((uint8_t*)lmt, strlen(lmt));
				 stop();
			 }
			 else {
				 step_motor(5000);
				 HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
			 }

	  }
}

void geserKiri(){
	   if (HAL_GPIO_ReadPin(BT3_GPIO_Port, BT3_Pin) == GPIO_PIN_RESET){
//			 sprintf(msg, "KIRI -> Encoder_A: %d\r\n Encoder_B: %d\r\n", last_encoder, last_encoder1);
//			 CDC_Transmit_FS((uint8_t*)msg, strlen(msg));

			 if (HAL_GPIO_ReadPin(Limit1_GPIO_Port, Limit1_Pin) == GPIO_PIN_RESET){
//				 sprintf(lmt, "KIRI -> Encoder_A: %d\r\n Encoder_B: %d\r\n", last_encoder, last_encoder1);
//				 CDC_Transmit_FS((uint8_t*)lmt, strlen(lmt));
				 stop();
			 }
			 else {
				 step_motor(-5000);
				 HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_SET);

			 }
	   }
}

#endif /* STEP_MOTOR_H_ */
